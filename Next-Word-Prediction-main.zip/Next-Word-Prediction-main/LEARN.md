# Learn about Next Word Prediction Using Markov Chain Model

- Read the [README.md](README.md) file for detailed info.
